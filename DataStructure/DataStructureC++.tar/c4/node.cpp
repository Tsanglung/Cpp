
class nodea;
class nodeb;

class nodea
{
private:
  int data1;
  char data2;
  float data3;
  nodea *linka;
  nodeb *linkb;
};

class nodeb
{
private:
   int data;
   nodeb *link;
};
